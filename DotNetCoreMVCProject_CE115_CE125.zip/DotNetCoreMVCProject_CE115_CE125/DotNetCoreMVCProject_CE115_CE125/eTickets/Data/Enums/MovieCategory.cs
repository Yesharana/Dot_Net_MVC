﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace eTickets.Data
{
    public enum MovieCategory
    {
        Action = 1,
        Comedy,
        Drama,
        Documentary,
        Cartoon,
        Horror
    }
}
